
	<div class="copy-right"> 
		<div class="container">
			<p>Online Tricycle Booking System ©2023</p>
		</div> 
	</div> 
	<!-- //footer -->   
	